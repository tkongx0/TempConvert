<html>
<h1>
Kelvin, Celsius, Fahrenheit, and Rankine Temperature Conversion
</h1>
<body>
<form action="s_process.php" method="post">

Select one of the options below.<br><br>
<button type="submit">Single Conversion</button><br>
</form>

<!-- <form action="m_process.php" method="post"> -->
<!-- <button type="submit">Multiple Conversions</button> -->
<!-- </form> -->
</body>
</html> 

